﻿using System;

namespace MauiAppHotel.Models
{
    public class Hospedagem
    {
        public Quarto QuartoSelecionado { get; set; }
        public int QtuAdultos { get; set; }
        public int QtuCriancas { get; set; }
        public DateTime DataCheckIn { get; set; }
        public DateTime DataCheckOut { get; set; }

        public int Estadia
        {
            get => (DataCheckOut - DataCheckIn).Days;
        }

        public double ValorTotal
        {
            get
            {
                double valorAdultos = QtuAdultos * (QuartoSelecionado?.ValorDiariaAdulto ?? 0);
                double valorCriancas = QtuCriancas * (QuartoSelecionado?.ValorDiariaCrianca ?? 0);
                double totalDia = valorAdultos + valorCriancas;
                return totalDia * (Estadia > 0 ? Estadia : 1);
            }
        }
    }
}