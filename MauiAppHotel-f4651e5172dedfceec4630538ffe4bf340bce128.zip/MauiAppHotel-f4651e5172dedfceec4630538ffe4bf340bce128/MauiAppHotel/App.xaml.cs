﻿using MauiAppHotel.Models;

namespace MauiAppHotel
{
    public partial class App : Application
    {
        public List<Quarto> lista_quartos { get; set; } = new List<Quarto>
        {
            new Quarto()
            {
                Descricao = "Suíte Luxo Minimalista",
                ValorDiariaAdulto = 150.0,
                ValorDiariaCrianca = 75.0
            },
            new Quarto()
            {
                Descricao = "Suíte Executiva Terracota",
                ValorDiariaAdulto = 100.0,
                ValorDiariaCrianca = 50.0
            },
            new Quarto()
            {
                Descricao = "Quarto Casal Standard",
                ValorDiariaAdulto = 80.0,
                ValorDiariaCrianca = 40.0
            }
        };

        public App()
        {
            InitializeComponent();

            MainPage = new NavigationPage(new Views.ContratacaoHospedagem());
        }
    }
}